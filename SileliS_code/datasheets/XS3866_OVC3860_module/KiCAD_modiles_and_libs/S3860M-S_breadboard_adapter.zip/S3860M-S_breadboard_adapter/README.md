breadboard adapter for the S3860M-S module (check markings on your module, this is not for the XS3868 module, nor BLK module!)
 
What's new in version 2.0:

buttons: on/off, reset, next, previous, volume up and down

jack: output (optional over 1206 caps (by default this is bypassed by PCB trace, so trace need to be cut for caps to work), mono mic + all required bias circuit

12+12pin headers


breadboard adapters for these bluetooth modules can be purchase at Tindie.com :

BLK-MD-SPK-B https://www.tindie.com/products/tomaskovacik/breadboard-adapter-for-blk-md-spk-b/

XS3886 / S3860M-s https://www.tindie.com/products/tomaskovacik/breadboard-adapter-for-s3860m-s-sx3868/

SOYO-BT24G03 https://www.tindie.com/products/tomaskovacik/breadboard-adapter-for-soyo-bt24g03-bt-module/

F-3188 https://www.tindie.com/products/tomaskovacik/breadboard-adapter-for-f-3188-csr8645-module/

