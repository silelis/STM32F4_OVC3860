diferential audio preamplifier for OVC3860 based bluetooth modules which have 0.9V on common pin of audio output


works with blk-md-spk-b, XS3868 and S3860M-S and others.


you can buy boards on tindie:


https://www.tindie.com/products/tomaskovacik/pcb-for-diferential-audio-amplifier/
